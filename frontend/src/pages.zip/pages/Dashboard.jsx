import React from "react";
import Sidebar from "../components/Sidebar";
import Navbar from "../components/Navbar";
import StatCard from "../components/StatCard";

import {
  PeopleFill,
  CameraVideoFill,
  EyeFill,
  BarChartFill
} from "react-bootstrap-icons";

import "../styles/dashboard.css";

const Dashboard = () => {
  return (
    <div className="dashboard-container">

      <Sidebar />

      <div className="dashboard-content">

        <Navbar />

        <div className="dashboard-header">

          <h2>Dashboard</h2>

          <p>
            Welcome back! Here's your consumer attention overview.
          </p>

        </div>

        {/* KPI Cards */}

        <div className="stats-grid">

          <StatCard
            title="Consumers Today"
            value="154"
            change="+12%"
            color="#0F766E"
            icon={<PeopleFill />}
          />

          <StatCard
            title="Active Cameras"
            value="08"
            change="Online"
            color="#2563EB"
            icon={<CameraVideoFill />}
          />

          <StatCard
            title="Average Attention"
            value="42 sec"
            change="+8%"
            color="#F59E0B"
            icon={<EyeFill />}
          />

          <StatCard
            title="Shelf Visits"
            value="89"
            change="+15%"
            color="#8B5CF6"
            icon={<BarChartFill />}
          />

        </div>

      </div>

    </div>
  );
};

export default Dashboard;