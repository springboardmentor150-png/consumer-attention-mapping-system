import "../styles/login.css";
import React, { useState } from "react";

// Adjust this import path to match where login-bg.jpg actually lives
// in your project (per your screenshot: src/assets/images/login-bg.jpg)
import loginBg from "../assets/images/login-bg.jpg";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    // TODO: wire up to your auth call
    console.log({ email, password });
  };

  return (
    <div className="login-page">
      <div className="login-card">

        {/* Left panel — your illustration */}
        <div
          className="login-visual"
          style={{ backgroundImage: `url(${loginBg})` }}
        >
          <div className="login-visual-text">
            <span className="login-visual-title">Welcome</span>
            <span className="login-visual-subtitle">to Consumer Attention Mapping System</span>
          </div>
        </div>

        {/* Right panel — the form */}
        <div className="login-form-panel">
          <h1 className="login-heading">Login</h1>

          <form className="login-form" onSubmit={handleSubmit}>
            <div className="field-group">
              <label htmlFor="email" className="sr-only">Email</label>
              <input
                id="email"
                type="email"
                placeholder="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>

            <div className="field-group field-with-link">
              <label htmlFor="password" className="sr-only">Password</label>
              <input
                id="password"
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
              <a href="/forgot-password" className="forgot-link">
                Forgot password?
              </a>
            </div>

            <button type="submit" className="login-btn">
              Login
            </button>
          </form>

          <p className="signup-text">
            Don&apos;t have an account? <a href="/signup">Sign up</a>
          </p>
        </div>
      </div>
    </div>
  );
}