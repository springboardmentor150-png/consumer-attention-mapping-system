import React from "react";
import {
  HouseDoor,
  CameraVideo,
  Shop,
  Grid,
  BarChart,
  FileEarmarkText,
  Person,
  Gear,
  BoxArrowRight
} from "react-bootstrap-icons";

import "../styles/Sidebar.css";

const Sidebar = () => {
  return (
    <div className="sidebar">

      <div className="sidebar-logo">
        <CameraVideo size={34} />
        <h4>CAMS</h4>
      </div>

      <ul className="sidebar-menu">

        <li className="active">
          <HouseDoor />
          <span>Dashboard</span>
        </li>

        <li>
          <CameraVideo />
          <span>Camera Management</span>
        </li>

        <li>
          <Shop />
          <span>Store Management</span>
        </li>

        <li>
          <Grid />
          <span>Shelf Management</span>
        </li>

        <li>
          <BarChart />
          <span>Analytics</span>
        </li>

        <li>
          <FileEarmarkText />
          <span>Reports</span>
        </li>

        <li>
          <Person />
          <span>Profile</span>
        </li>

        <li>
          <Gear />
          <span>Settings</span>
        </li>

      </ul>

      <div className="logout">

        <BoxArrowRight />

        <span>Logout</span>

      </div>

    </div>
  );
};

export default Sidebar;